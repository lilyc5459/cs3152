PATHOGENSIS ALPHA play instructions:

WASD to move
Hold SPACE to convert, conversion range is displayed as a red circle

To win, infect both target infection points the same way you convert enemies. They are shaped like holes in the ground, indended to look like a blood vessel coming out of the ground.

Health displayed at top left
Conversion power displayed at top right

Collect white items to increase health
Collect blue items to increase conversion power (will be changed to recharge over time since it was found to be a bit annoying to have to collect them)

Enemies and items spawn randomly (100 enemies max) - this will all change later with level design, spawn points, regions, etc

Blue enemies are UNCONVERTABLE. (Will change to have slightly different art later)